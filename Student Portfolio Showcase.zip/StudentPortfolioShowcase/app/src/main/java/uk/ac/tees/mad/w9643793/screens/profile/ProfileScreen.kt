package uk.ac.tees.mad.w9643793.screens.profile

import androidx.compose.runtime.Composable

@Composable
fun ProfileScreen() {
    
}