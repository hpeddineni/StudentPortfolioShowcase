package uk.ac.tees.mad.w9643793

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class StudentPortfolioApp: Application() {
}