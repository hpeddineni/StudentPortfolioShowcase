package uk.ac.tees.mad.w9643793.screens.profile.post

data class PostUiState(
    val images: List<String> = listOf(),
)